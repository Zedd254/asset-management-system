See https://snipe-it.readme.io/docs/docker for Docker information
