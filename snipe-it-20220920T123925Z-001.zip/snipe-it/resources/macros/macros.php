<?php
/**
* Macro helpers
*
*/


/**
* Locale macro
* Generates the dropdown menu of available languages
*/
Form::macro('locales', function ($name = "locale", $selected = null, $class = null, $id = null) {

    $locales = array(
      ''=> " ",
      'en'=> "English, US",
      'en-GB'=> "English, UK",
      'af'=> "Afrikaans",
      'ar'=> "Arabic",
      'bg'=> "Bulgarian",
      'zh-CN'=> "Chinese Simplified",
      'zh-TW'=> "Chinese Traditional",
      'hr'=> "Croatian",
      'cs'=> "Czech",
      'da'=> "Danish",
      'nl'=> "Dutch",
      'en-ID'=> "English, Indonesia",
      'et'=> "Estonian",
      'fi'=> "Finnish",
      'fr'=> "French",
      'de'=> "German",
      'el'=> "Greek",
      'he'=> "Hebrew",
      'hu'=> "Hungarian",
      'is' => 'Icelandic',
      'id'=> "Indonesian",
      'ga-IE'=> "Irish",
      'it'=> "Italian",
      'ja'=> "Japanese",
      'ko'=> "Korean",
      'lv'=>'Latvian',
      'lt'=> "Lithuanian",
      'ms'=> "Malay",
      'mi'=> "Maori",
      'mk'=> "Macedonian",
      'mn'=> "Mongolian",
      'no'=> "Norwegian",
      'fa'=> "Persian",
      'pl'=> "Polish",
      'pt-PT'=> "Portuguese",
      'pt-BR'=> "Portuguese, Brazilian",
      'ro'=> "Romanian",
      'ru'=> "Russian",
      'sr-CS' => 'Serbian (Latin)',
      'sl'=> "Slovenian",
      'es-ES'=> "Spanish",
      'es-CO'=> "Spanish, Colombia",
      'es-VE'=> "Spanish, Venezuela",
      'sv-SE'=> "Swedish",
      'tl'=> "Tagalog",
      'ta'=> "Tamil",
      'th'=> "Thai",
      'tr'=> "Turkish",
      'uk'=> "Ukranian",
      'vi'=> "Vietnamese",
      'zu'=> "Zulu",
    );

    $idclause='';
    if($id) {
      $idclause=" id='$id'";
    }
    $select = '<select name="'.$name.'" class="'.$class.'" style="min-width:350px"'.$idclause.'>';

    foreach ($locales as $abbr => $locale) {
        $select .= '<option value="'.$abbr.'"'.($selected == $abbr ? ' selected="selected"' : '').'>'.$locale.'</option> ';
    }

    $select .= '</select>';

    return $select;

});


/**
* Country macro
* Generates the dropdown menu of countries for the profile form
*/
Form::macro('countries', function ($name = "country", $selected = null, $class = null, $id = null) {

    $countries = array(
    ''=>"Select a County",
    'AE'=>'Baringo County',
    'AF'=>'Bomet County',
    'AG'=>'Bungoma County',
    'AI'=>'Busia County',
    'AL'=>'Embu County',
    'AM'=>'Garissa County',
    'AN'=>'Homa Bay County',
    'AO'=>'Isiolo County',
    'AQ'=>'Kajiado County',
    'AR'=>'Kakamega County',
    'AS'=>'Kericho County',
    'AT'=>'Kiambu County',
    'AU'=>'Kilifi County',
    'AW'=>'Kirinyaga County',
    'AX'=>'Kisii County',
    'AZ'=>'Kisumu County',
    'BA'=>'Kitui County',
    'BB'=>'Kwale County',
    'BE'=>'Laikipia County',
    'BD'=>'Lamu County',
    'BF'=>'Machakos County',
    'BG'=>'Makueni County',
    'BH'=>'Mandera County',
    'BI'=>'Meru County',
    'BJ'=>'Migori County',
    'BM'=>'Marsabit County',
    'BN'=>'Mombasa County',
    'BO'=>'Muranga County',
    'BR'=>'Nairobi County',
    'BS'=>'Nakuru County',
    'BT'=>'Nandi County',
    'BV'=>'Narok County',
    'BW'=>'Nyamira County',
    'BY'=>'Nyandarua County',
    'BZ'=>'Nyeri County',
    'CA'=>'Samburu County',
    'CC'=>'Siaya County',
    'CD'=>'Taita Taveta County',
    'CF'=>'Tana River County',
    'CG'=>'Tharaka Nithi County',
    'CH'=>'Trans Nzoia County',
    'CI'=>'Turkana County',
    'CK'=>'Uasin Gishu County',
    'CL'=>'Wajir County',
    'CM'=>'West Pokot County',
   
    );

    $idclause='';
    if($id) {
      $idclause=" id='$id'";
    }
    $select = '<select name="'.$name.'" class="'.$class.'" style="min-width:350px"'.$idclause.'>';

    foreach ($countries as $abbr => $country) {
        $select .= '<option value="'.strtoupper($abbr).'"'.(strtoupper($selected)== strtoupper($abbr) ? ' selected="selected"' : '').'>'.$country.'</option> ';
    }

    $select .= '</select>';

    return $select;

});



Form::macro('date_display_format', function ($name = "date_display_format", $selected = null, $class = null) {

    $formats = [
        'Y-m-d',
        'Y-m-d',
        'D M d, Y',
        'M j, Y',
        'd M, Y',
        'm/d/Y',
        'n/d/y',
        'd/m/Y',
        'm/j/Y',
        'd.m.Y',
        'Y.m.d.',
    ];

    foreach ($formats as $format) {

        $date_display_formats[$format] = Carbon::parse(date('Y').'-'.date('m').'-25')->format($format);
    }
    $select = '<select name="'.$name.'" class="'.$class.'" style="min-width:250px">';
    foreach ($date_display_formats as $format => $date_display_format) {
        $select .= '<option value="'.$format.'"'.($selected == $format ? ' selected="selected"' : '').'>'.$date_display_format.'</option> ';
    }

    $select .= '</select>';
    return $select;

});


Form::macro('time_display_format', function ($name = "time_display_format", $selected = null, $class = null) {

    $formats = [
        'g:iA',
        'h:iA',
        'H:i',
    ];

    foreach ($formats as $format) {
        $time_display_formats[$format] = Carbon::now()->format($format);
    }
    $select = '<select name="'.$name.'" class="'.$class.'" style="min-width:150px">';
    foreach ($time_display_formats as $format => $time_display_format) {
        $select .= '<option value="'.$format.'"'.($selected == $format ? ' selected="selected"' : '').'>'.$time_display_format.'</option> ';
    }

    $select .= '</select>';
    return $select;

});

/**
* Barcode macro
* Generates the dropdown menu of available 1D barcodes
*/
Form::macro('alt_barcode_types', function ($name = "alt_barcode", $selected = null, $class = null) {

    $barcode_types = array(
        'C128',
        'C39',
        'PDF417',
        'EAN5',

    );

    $select = '<select name="'.$name.'" class="'.$class.'">';
    foreach ($barcode_types as $barcode_type) {
        $select .= '<option value="'.$barcode_type.'"'.($selected == $barcode_type ? ' selected="selected"' : '').'>'.$barcode_type.'</option> ';
    }

    $select .= '</select>';

    return $select;

});


/**
* Barcode macro
* Generates the dropdown menu of available 2D barcodes
*/
Form::macro('barcode_types', function ($name = "barcode_type", $selected = null, $class = null) {

    $barcode_types = array(
        'QRCODE',
        'DATAMATRIX',

    );

    $select = '<select name="'.$name.'" class="'.$class.'">';
    foreach ($barcode_types as $barcode_type) {
        $select .= '<option value="'.$barcode_type.'"'.($selected == $barcode_type ? ' selected="selected"' : '').'>'.$barcode_type.'</option> ';
    }

    $select .= '</select>';

    return $select;

});

Form::macro('username_format', function ($name = "username_format", $selected = null, $class = null) {

    $formats = array(
        'firstname.lastname' => trans('general.firstname_lastname_format'),
        'firstname' => trans('general.first_name_format'),
        'filastname' => trans('general.filastname_format'),
        'lastnamefirstinitial' => trans('general.lastnamefirstinitial_format'),
        'firstname_lastname' => trans('general.firstname_lastname_underscore_format'),

    );

    $select = '<select name="'.$name.'" class="'.$class.'" style="width: 100%">';
    foreach ($formats as $format => $label) {
        $select .= '<option value="'.$format.'"'.($selected == $format ? ' selected="selected"' : '').'>'.$label.'</option> '."\n";
    }

    $select .= '</select>';

    return $select;

});

Form::macro('two_factor_options', function ($name = "two_factor_enabled", $selected = null, $class = null) {

    $formats = array(
        '' => trans('admin/settings/general.two_factor_disabled'),
        '1' => trans('admin/settings/general.two_factor_optional'),
        '2' => trans('admin/settings/general.two_factor_required'),

    );

    $select = '<select name="'.$name.'" class="'.$class.'">';
    foreach ($formats as $format => $label) {
        $select .= '<option value="'.$format.'"'.($selected == $format ? ' selected="selected"' : '').'>'.$label.'</option> '."\n";
    }

    $select .= '</select>';

    return $select;

});


Form::macro('customfield_elements', function ($name = "customfield_elements", $selected = null, $class = null) {

    $formats = array(
        'text' => 'Text Box',
        'listbox' => 'List Box',
        'textarea' => 'Textarea (multi-line) ',
     //   'checkbox' => 'Checkbox',
     //   'radio' => 'Radio Buttons',
    );

    $select = '<select name="'.$name.'" class="'.$class.'" style="width: 100%">';
    foreach ($formats as $format => $label) {
        $select .= '<option value="'.$format.'"'.($selected == $format ? ' selected="selected"' : '').'>'.$label.'</option> '."\n";
    }

    $select .= '</select>';

    return $select;

});



Form::macro('skin', function ($name = "skin", $selected = null, $class = null) {

    $formats = array(
        '' => 'Default Blue',
        'green-dark' => 'Green Dark',
        'red-dark' => 'Red Dark',
        'orange-dark' => 'Orange Dark',
    );

    $select = '<select name="'.$name.'" class="'.$class.'" style="width: 250px">';
    foreach ($formats as $format => $label) {
        $select .= '<option value="'.$format.'"'.($selected == $format ? ' selected="selected"' : '').'>'.$label.'</option> '."\n";
    }

    $select .= '</select>';
    return $select;

});
