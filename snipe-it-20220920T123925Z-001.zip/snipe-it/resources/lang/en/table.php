<?php

return array(

    'actions'	 	=> 'Actions',
    'action' 		=> 'Action',
    'by'      		=> 'By',
    'item' 			=> 'Item',

);
