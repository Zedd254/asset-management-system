<?php
return array(
    'companies' => 'Companies',
    'create'    => 'Create Company',
    'title'     => 'Company',
    'update'    => 'Update Company',
    'name'      => 'Company Name',
    'id'        => 'ID',
);
