<?php
return [
    'about_companies_title'            => 'About Companies',
    'about_companies_text'                  => 'Companies can be used as a simple identifier field, or can be used to limit visibility of assets, users, etc if full company support is enabled in your Admin settings.',
    'select_company' => 'Select Company',
];
