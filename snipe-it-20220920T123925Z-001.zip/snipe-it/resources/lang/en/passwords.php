<?php

return [
    'sent'	        => 'Your password link has been sent!',
    'user'			=> 'No matching active user found with that email.',
];

