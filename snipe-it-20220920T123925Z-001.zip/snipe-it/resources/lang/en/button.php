<?php

return array(
    'actions' 	                => 'Actions',
    'add'    	                => 'Add New',
    'cancel'                    => 'Cancel',
    'checkin_and_delete'  	    => 'Checkin & Delete User',
    'delete'  	                => 'Delete',
    'edit'    	                => 'Edit',
    'restore' 	                => 'Restore',
    'request'                   => 'Request',
    'submit'  	                => 'Submit',
    'upload'                    => 'Upload',
	'select_file'				=> 'Select File...',
    'select_files'				=> 'Select Files...',
);
