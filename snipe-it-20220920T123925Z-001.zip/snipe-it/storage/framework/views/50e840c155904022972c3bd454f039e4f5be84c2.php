<tr>
    <td class="header"<?php echo ($snipeSettings->header_color!='') ? ' style="background-color: '.e($snipeSettings->header_color).'"' : ''; ?>>
        <?php if(($snipeSettings->show_images_in_email=='1' ) && ($snipeSettings::setupCompleted())): ?>

            <?php if($snipeSettings->brand == '3'): ?>
                <?php if($snipeSettings->logo!=''): ?>
                    <img class="navbar-brand-img logo" src="<?php echo e(url('/')); ?>/uploads/<?php echo e($snipeSettings->logo); ?>">
                <?php endif; ?>
                <?php echo e($snipeSettings->site_name); ?>


            <?php elseif($snipeSettings->brand == '2'): ?>
                <?php if($snipeSettings->logo!=''): ?>
                    <img class="navbar-brand-img logo" src="<?php echo e(url('/')); ?>/uploads/<?php echo e($snipeSettings->logo); ?>">
                <?php endif; ?>
            <?php else: ?>
                <?php echo e($snipeSettings->site_name); ?>

            <?php endif; ?>
        <?php else: ?>
            Snipe-IT
        <?php endif; ?>
    </td>
</tr>
