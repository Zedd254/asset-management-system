<?php $__env->startSection('title'); ?>
    Bulk Edit
    ##parent-placeholder-3c6de1b7dd91465d437ef415f94f36afc1fbc8a8##
<?php $__env->stopSection(); ?>


<?php $__env->startSection('header_right'); ?>
    <a href="<?php echo e(URL::previous()); ?>" class="btn btn-sm btn-primary pull-right">
        <?php echo e(trans('general.back')); ?></a>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-8 col-md-offset-2">

            <form class="form-horizontal" method="post" action="<?php echo e(route('models.bulkedit.store')); ?>" autocomplete="off" role="form">
                <?php echo e(csrf_field()); ?>


                <div class="box box-default">
                    <div class="box-header with-border">
                        <?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="box-title"><b><?php echo e($model->display_name); ?></b> (<?php echo e($model->model_number); ?>)</span><br />
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="box-body">
                        <!-- manufacturer -->
                        <?php echo $__env->make('partials.forms.edit.manufacturer-select', ['translated_name' => trans('general.manufacturer'), 'fieldname' => 'manufacturer_id'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                        <!-- category -->
                        <?php echo $__env->make('partials.forms.edit.category-select', ['translated_name' => trans('admin/categories/general.category_name'), 'fieldname' => 'category_id', 'required' => 'true', 'category_type' => 'asset'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                        <!-- custom fields -->
                        <div class="form-group <?php echo e($errors->has('fieldset_id') ? ' has-error' : ''); ?>">
                            <label for="category_id" class="col-md-3 control-label">
                                <?php echo e(trans('admin/models/general.fieldset')); ?>

                            </label>
                            <div class="col-md-7">
                                <?php echo e(Form::select('fieldset_id', $fieldset_list , Input::old('fieldset_id', 'NC'), array('class'=>'select2 js-fieldset-field', 'style'=>'width:350px'))); ?>

                                <?php echo $errors->first('fieldset_id', '<span class="alert-msg"><br><i class="fa fa-times"></i> :message</span>'); ?>

                            </div>
                        </div>

                        <!-- depreciation -->

                        <div class="form-group <?php echo e($errors->has('depreciation_id') ? ' has-error' : ''); ?>">
                            <label for="category_id" class="col-md-3 control-label">
                                <?php echo e(trans('general.depreciation')); ?>

                            </label>
                            <div class="col-md-7">
                                <?php echo e(Form::select('depreciation_id', $depreciation_list , Input::old('depreciation_id', 'NC'), array('class'=>'select2', 'style'=>'width:350px'))); ?>

                                <?php echo $errors->first('depreciation_id', '<span class="alert-msg"><i class="fa fa-times"></i> :message</span>'); ?>

                            </div>
                        </div>

                        <?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <input type="hidden" name="ids[<?php echo e($model->id); ?>]" value="<?php echo e($model->id); ?>">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div> <!--/.box-body-->

                    <div class="box-footer text-right">
                        <button type="submit" class="btn btn-success"><i class="fa fa-check icon-white"></i> <?php echo e(trans('general.save')); ?></button>
                    </div>
                </div> <!--/.box.box-default-->
            </form>
        </div> <!--/.col-md-8-->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>