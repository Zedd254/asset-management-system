<?php
return array (
  'app_version' => 'v4.6.17',
  'full_app_version' => 'v4.6.17 - build 4026-g888bdbdb6',
  'build_version' => '4026',
  'prerelease_version' => '',
  'hash_version' => 'g888bdbdb6',
  'full_hash' => 'v4.6.17-7-g888bdbdb6',
  'branch' => 'master',
);
